# backbone-handlebars-js

It's a 2 way binding adapter for backbone and handlebars.

See sample01.html

### License

The project is licensed under the WTFPL.
http://sam.zoy.org/wtfpl/
